let title_el = document.querySelector("title");

var songTitle = document.getElementById('songTitle');
var SongArtist = document.getElementById('SongArtist');
var songSlider = document.getElementById('songSlider');
var currentTime = document.getElementById('currentTime');
var duration = document.getElementById('duration');
var volumeSlider = document.getElementById('volumeSlider');
var nextSongTitle = document.getElementById('nextSongTitle');
var nextSongArtist = document.getElementById('nextSongArtist');

var song = new Audio();
var currentSong = 0;
var currentArtist =0;

window.onload = loadSong;

function loadSong () {
	song.src = "assets/music_galery/ogg/" + songs[currentSong];
	songTitle.textContent = (currentSong + 1) + ". " + songs[currentSong];
	SongArtist.textContent = (currentArtist + 1) + ". " + songartist[currentArtist];
	nextSongTitle.innerHTML = "<b>Next Song: </b>" + songs[currentSong + 1 % songs.length];
	nextSongArtist.innerHTML = "<b>Next Artist: </b>" + songartist[currentArtist + 1 % songartist.length];
	song.playbackRate = 1;
	song.volume = volumeSlider.value;
	song.play();
	setTimeout(showDuration, 1000);
	
	if(title_el)
    title_el.innerHTML = "Song Title: " + songs[currentSong];
   
}
setInterval(updateSongSlider, 1000);

function updateSongSlider () {
	var c = Math.round(song.currentTime);
	songSlider.value = c;
	currentTime.textContent = convertTime(c);
	if(song.ended){
		next();
	}
}

function convertTime (secs) {
	var min = Math.floor(secs/60);
	var sec = secs % 60;
	min = (min < 10) ? "0" + min : min;
	sec = (sec < 10) ? "0" + sec : sec;
	return (min + ":" + sec);
}

function showDuration () {
	var d = Math.floor(song.duration);
	songSlider.setAttribute("max", d);
	duration.textContent = convertTime(d);
}

function playOrPauseSong (img) {
	song.playbackRate = 1;
	if(song.paused){
		song.play();
		img.src = "assets/images/img3/ClickPauseButton.png";
	}else{
		song.pause();
		img.src = "assets/images/img3/ClickPlayButton.png";
	}
}

function next(){
	currentSong = currentSong + 1 % songs.length;
	currentArtist = currentArtist + 1 % songartist.length;
	loadSong();
}

function previous () {
	currentSong--;
	currentArtist--;
	currentSong = (currentSong < 0) ? songs.length - 1 : currentSong;
	currentArtist = (currentArtist < 0) ? songartist.length - 1 : currentArtist;
	loadSong();
}

function seekSong () {
	song.currentTime = songSlider.value;
	currentTime.textContent = convertTime(song.currentTime);
}

function adjustVolume () {
	song.volume = volumeSlider.value;
}
/*
function increasePlaybackRate () {
	songs.playbackRate += 0.5;
}

function decreasePlaybackRate () {
	songs.playbackRate -= 0.5;
}
*/