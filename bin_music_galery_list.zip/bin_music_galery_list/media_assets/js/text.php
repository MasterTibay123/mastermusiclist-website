<?php
echo realpath("master.txt");
?>