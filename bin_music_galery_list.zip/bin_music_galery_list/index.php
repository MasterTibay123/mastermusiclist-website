<?php 
header("Location: loader/"); 
exit(); 
?>