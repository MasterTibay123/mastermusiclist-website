<?php
$cookie_name = "name";
$cookie_value = "Master";
setrawcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
?>
<html>
<head>

<meta http-equiv="refresh" content="0;url=../../../inc_music_list/ama,_kami_ay_sa_iyo_pa_rin/" >

<title>loading</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
        <meta charset="UTF-8">
<meta name="description" content="Free Web Music">
<meta name="keywords" content="HTML,CSS, JavaScript">
<meta name="author" content="Jayar Tibay">
<link rel="stylesheet" type="text/css" href="../../../media_assets/css/index.css">
<link rel="stylesheet" type="text/css" href="../../../media_assets/css/loader.css">
    </head>
</head>
<body onload="myFunction()">
    <div id="loader">
    <img src="../../../media_assets/images/background_images/welcome.gif" />
    </div>
<br>
<font class="h">
      <script type="text/javascript" src="../../../media_assets/js/loader.js"></script>
</font>
</body>
</html>