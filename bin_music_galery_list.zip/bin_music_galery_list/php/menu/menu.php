<?php
echo '<div id="menu">
<ul>
<li><a href="#">MP4</a>
<ul>
<li><a href="../php/video_files/main_access_video_galery_1.php">Access</a></li>
<li><a href="../php/video_files/main_audio_video_galery.php">Audio Player Demo</a></li>
<li><a href="../php/video_files/cartoons.php">Cartoon</a></li>
<li><a href="../php/video_files/main_csharp.php">C# Video</a></li>
<li><a href="../php/video_files/inc_video_galery.php">INC Music Video</a></li>
<li><a href="../php/video_files/java_video_galery.php">Java Video</a></li>
<li><a href="../php/video_files/basic_video_galery.php">Visual Basic</a></li>
</ul>
</li>
<li><a href="#">I LOVE MUSIC</a>
<ul>
<li><a href="../php/my_love_music/i_love_music.php">Music Playlist </a></li>
<li><a href="../php/my_love_music/graduation_list.php">Graduation Songs</a></li>
<li><a href="../php/clock/analog_clock.php">Analog Clock</a></li>
<li><a href="../php/clock/digital_clock.php">Digital Clock</a></li>
<li><a href="../php/my_love_music/huwag_kang_susuko.php">Huwag Kang Susuko</a></li>
<li><a href="../php/my_love_music/kulang_ang_sandali.php">Kulang Ang Sandali</a></li>
<li><a href="../php/my_love_music/pagibig_koy_pansinin.php">Pagibig koy Pansinin</a></li>
<li><a href="../php/my_love_music/krizza_neri_love_song_playlist.php">Krizza Neri Love Song</a></li>
</ul>
</li>
<li><a href="#">INCMUSIC</a>
<ul id="tran">
<li><a href="../php/inc_music/ama,_kami_ay_sa_iyo_pa_rin.php">Ama, Kami Ay Sa Iyo Pa Rin</a></li>
<li><a href="../php/inc_music/awit_ng_anak.php">Awit Ng Anak</a></li>
<li><a href="../php/inc_music/best_inc_music.php">Best INC Music</a></li>
<li><a href="../php/inc_music/compilation_of_inc_songs.php">Compilation Of Iglesia Ni Cristo Songs</a></li>
<li><a href="../php/inc_music/forever_inc.php">Forever INC Full Album</a></li>
<li><a href="../php/inc_music/inc_music.php">INC MUSIC PLAYLIST</a></li>
<li><a href="../php/inc_music/i_am_strong.php">I am Strong by Chiarra Dabu</a></li>
<li><a href="../php/inc_music/pagibig_sa_iglesia.php">Pagibig Sa Iglesia</a></li>
<li><a href="../php/inc_music/sasalubong_ako_sa_iyo_aking_jesus.php">Sasalubong Ako Sa Iyo</a></li>
<li><a href="../php/inc_music/inc_version.php" >Titibo-tibo</a></li>
</ul>
</li>
<li><a href="#">RESOURCES</a>
<ul id="tran">
<li><a href="../php/info.php">PHP INFORMATION</a></li>
<li><a href="../php/xml_server/xml.php">Xml Files</a></li>
<li><a href="../php/best_inc_music_firefox.php">Firefox INC Music</a></li>
<li><a href="../php/xml_server/read_text.php">Text File</a></li>
</ul>
</li>
</ul>
</div>';
?>